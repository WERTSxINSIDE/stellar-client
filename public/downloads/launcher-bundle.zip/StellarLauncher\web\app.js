(() => {
  "use strict";

  const state = {
    accounts: [],
    activeAccount: null,
    settings: null,
    mods: [],
    busy: false,
    installed: false,
    loginActive: false,
    siteUrl: "https://stellar-client.vercel.app",
    searchResults: [],
    searchError: "",
    searching: false,
    installing: {},
    installedSearch: {},
  };

  const phaseLabels = {
    Java: "Java",
    "Метаданные": "Метаданные",
    "Ресурсы": "Ресурсы",
    Файлы: "Файлы",
    Загрузка: "Загрузка",
    Сборка: "Сборка",
    Запуск: "Запуск",
    Аккаунт: "Аккаунт",
  };

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  function send(payload) {
    const api = window.chrome && window.chrome.webview;
    if (api) {
      api.postMessage(payload);
    }
  }

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function formatBytes(bytes) {
    if (!bytes || bytes <= 0) return "0 Б";
    const units = ["Б", "КБ", "МБ", "ГБ"];
    let value = bytes;
    let unit = 0;
    while (value >= 1024 && unit < units.length - 1) {
      value /= 1024;
      unit += 1;
    }
    const digits = unit === 0 ? 0 : value >= 100 ? 0 : value >= 10 ? 1 : 2;
    return value.toFixed(digits) + " " + units[unit];
  }

  function formatRam(mb) {
    const gb = mb / 1024;
    return (Number.isInteger(gb) ? gb : gb.toFixed(1)) + " ГБ";
  }

  function formatCount(value) {
    const number = Number(value) || 0;
    if (number >= 1000000) {
      const short = number / 1000000;
      return (short >= 10 ? Math.round(short) : short.toFixed(1)) + "M";
    }
    if (number >= 1000) {
      const short = number / 1000;
      return (short >= 10 ? Math.round(short) : short.toFixed(1)) + "K";
    }
    return String(number);
  }

  function formatSiteDate(value) {
    if (!value) return "";
    const text = String(value);
    const date = new Date(text.includes("T") ? text : text.replace(" ", "T") + "Z");
    if (Number.isNaN(date.getTime())) return text;
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    return day + "." + month + "." + date.getFullYear();
  }

  function initial(name) {
    const value = String(name || "?").trim();
    return value ? value[0].toUpperCase() : "?";
  }

  function gradientClass(name) {
    let hash = 0;
    for (const ch of String(name || "?")) {
      hash = (hash * 31 + ch.charCodeAt(0)) & 0xffffffff;
    }
    return "avatar-g" + (Math.abs(hash) % 4);
  }

  function toast(kind, text) {
    const host = $("#toasts");
    const node = document.createElement("div");
    node.className = "toast toast-" + (kind || "info");
    node.textContent = text;
    host.appendChild(node);
    while (host.children.length > 4) {
      host.removeChild(host.firstChild);
    }
    setTimeout(() => {
      node.classList.add("is-out");
      setTimeout(() => node.remove(), 220);
    }, 4200);
  }

  function navigate(page) {
    $$(".nav-item").forEach((item) => {
      item.classList.toggle("is-active", item.dataset.page === page);
    });
    $$(".page").forEach((section) => {
      section.classList.toggle("is-active", section.id === "page-" + page);
    });
    if (page === "logs") {
      send({ cmd: "refreshLogs" });
    }
    if (page === "mods") {
      send({ cmd: "refreshMods" });
    }
  }

  function setActiveAccountUI() {
    const account = state.activeAccount;
    const name = account ? account.name : "Нет аккаунта";
    const type = account ? "Аккаунт сайта" : "Войди в аккаунт сайта";

    ["side-avatar", "play-avatar"].forEach((id) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.textContent = account ? initial(account.name) : "?";
      el.className = el.className.replace(/avatar-g\d/g, "").trim();
      if (account) {
        el.classList.add(gradientClass(account.name));
      } else {
        el.classList.remove("avatar-g0", "avatar-g1", "avatar-g2", "avatar-g3");
      }
    });

    $("#side-name").textContent = name;
    $("#side-type").textContent = type;
    $("#play-name").textContent = account ? account.name : "Аккаунт не выбран";
    $("#play-type").textContent = account
      ? account.subscriptionEnd
        ? "Подписка до " + formatSiteDate(account.subscriptionEnd)
        : "Аккаунт сайта Stellar"
      : "Войди в аккаунт сайта";
    $("#play-account").textContent = account ? account.name : "не выбран";

    $("#greeting").textContent = account ? "Привет, " + account.name : "Привет";
    $("#greeting-sub").textContent = account
      ? state.installed
        ? "Всё на месте — можно запускать."
        : "Первый запуск: скачаем игру и моды."
      : "Войди в аккаунт сайта, чтобы начать.";

    $("#play-desc").textContent = state.installed
      ? "Файлы на месте, моды собраны. Осталось нажать «Играть»."
      : "Скачаем Minecraft 26.2 и моды при первом запуске — больше ничего делать не нужно.";

    const button = $("#btn-play");
    button.disabled = state.busy || !account;
    $("#play-hint").textContent = state.busy
      ? "Идёт подготовка файлов"
      : account
        ? state.installed
          ? "Файлы готовы"
          : "При первом запуске скачаем файлы игры"
        : "Аккаунт не выбран";
    $("#play-text").textContent = state.busy ? "Подождите" : "Играть";

    const loginButton = $("#btn-site-login");
    loginButton.disabled = state.loginActive;
    loginButton.textContent = state.loginActive ? "Входим…" : "Войти";
  }

  function renderAccounts() {
    const list = $("#account-list");
    const empty = $("#accounts-empty");
    $("#accounts-count").textContent = state.accounts.length;

    if (!state.accounts.length) {
      list.innerHTML = "";
      empty.classList.remove("is-hidden");
      return;
    }
    empty.classList.add("is-hidden");

    list.innerHTML = state.accounts
      .map((account) => {
        const active = state.activeAccount && state.activeAccount.id === account.id;
        const type = account.site ? "Stellar" : "Аккаунт";
        const sub = account.subscriptionEnd
          ? " · подписка до " + formatSiteDate(account.subscriptionEnd)
          : "";
        return (
          '<div class="account-item account-row' +
          (active ? " is-active" : "") +
          '" data-id="' +
          escapeHtml(account.id) +
          '">' +
          '<div class="avatar ' +
          gradientClass(account.name) +
          '">' +
          escapeHtml(initial(account.name)) +
          "</div>" +
          '<div class="account-info">' +
          "<strong>" +
          escapeHtml(account.name) +
          "</strong>" +
          '<span class="muted">' +
          escapeHtml(type + sub) +
          "</span>" +
          "</div>" +
          '<div class="account-actions">' +
          (active
            ? '<span class="selected-badge">Выбран</span>'
            : '<button class="ghost-btn" data-action="select">Выбрать</button>') +
          '<button class="icon-btn" data-action="remove" title="Удалить" aria-label="Удалить">×</button>' +
          "</div>" +
          "</div>"
        );
      })
      .join("");
  }

  function renderMods() {
    const list = $("#mods-list");
    const empty = $("#mods-empty");
    const count = state.mods.length;

    $("#mods-count").textContent = count;
    $("#play-mods").textContent = count;
    $("#stat-mods").textContent = count;

    if (!count) {
      list.innerHTML = "";
      empty.classList.remove("is-hidden");
      return;
    }
    empty.classList.add("is-hidden");

    list.innerHTML = state.mods
      .map((mod) => {
        const enabled = Boolean(mod.enabled);
        const core = Boolean(mod.core);
        const rowClass = "mod-row" + (core ? " is-core" : "") + (enabled ? "" : " is-off");
        const subtitle = formatBytes(mod.size) + (enabled ? "" : " · выключен");

        const controls = core
          ? '<span class="mod-tag">сборка</span>'
          : '<label class="switch" title="' +
            (enabled ? "Выключить" : "Включить") +
            '"><input type="checkbox" data-action="toggle"' +
            (enabled ? " checked" : "") +
            '><span></span></label>' +
            '<button class="mod-remove" data-action="remove" title="Удалить">×</button>';

        return (
          '<div class="' +
          rowClass +
          '" data-file="' +
          escapeHtml(mod.file) +
          '">' +
          '<div class="mod-icon">JAR</div>' +
          '<div class="mod-info"><strong title="' +
          escapeHtml(mod.file) +
          '">' +
          escapeHtml(mod.name) +
          "</strong><span>" +
          escapeHtml(subtitle) +
          "</span></div>" +
          controls +
          "</div>"
        );
      })
      .join("");
  }

  function renderSearchResults() {
    const host = $("#search-results");

    if (state.searching) {
      host.classList.remove("is-hidden");
      host.innerHTML = '<div class="search-empty">Ищем на Modrinth…</div>';
      return;
    }
    if (state.searchError) {
      host.classList.remove("is-hidden");
      host.innerHTML =
        '<div class="search-empty is-error">' + escapeHtml(state.searchError) + "</div>";
      return;
    }
    if (!state.searchResults.length) {
      host.classList.add("is-hidden");
      host.innerHTML = "";
      return;
    }

    host.classList.remove("is-hidden");
    host.innerHTML = state.searchResults
      .map((mod) => {
        const installing = Boolean(state.installing[mod.id]);
        const installed = Boolean(state.installedSearch[mod.id]);
        const author = mod.author ? "by " + mod.author : "";
        const meta = [author, mod.downloads ? formatCount(mod.downloads) + " загрузок" : ""]
          .filter(Boolean)
          .join(" · ");

        let action;
        if (installed) {
          action = '<span class="mod-tag">установлен</span>';
        } else {
          action =
            '<button class="mod-download" data-download="' +
            escapeHtml(mod.id) +
            '"' +
            (installing ? " disabled" : "") +
            ">" +
            (installing ? "Скачиваем…" : "Скачать") +
            "</button>";
        }

        return (
          '<div class="search-result">' +
          '<div class="search-icon" data-name="' +
          escapeHtml(initial(mod.title)) +
          '">' +
          (mod.icon
            ? '<img src="' + escapeHtml(mod.icon) + '" alt="" loading="lazy" referrerpolicy="no-referrer">'
            : escapeHtml(initial(mod.title))) +
          "</div>" +
          '<div class="search-result-info">' +
          '<div class="search-result-title"><strong>' +
          escapeHtml(mod.title) +
          "</strong><span>" +
          escapeHtml(meta) +
          "</span></div>" +
          '<div class="search-result-desc">' +
          escapeHtml(mod.description || "") +
          "</div>" +
          "</div>" +
          action +
          "</div>"
        );
      })
      .join("");

    host.querySelectorAll(".search-icon img").forEach((image) => {
      image.addEventListener("error", () => {
        const wrap = image.parentElement;
        if (!wrap) return;
        wrap.textContent = wrap.dataset.name || "?";
      });
    });
  }

  function applyState(data) {
    state.accounts = Array.isArray(data.accounts) ? data.accounts : [];
    state.activeAccount = data.activeAccount || null;
    state.settings = data.settings || state.settings;
    state.mods = Array.isArray(data.mods) ? data.mods : [];
    state.busy = Boolean(data.busy);
    state.installed = Boolean(data.installed);
    state.loginActive = Boolean(data.loginActive);
    if (data.siteUrl) state.siteUrl = data.siteUrl;
    if (data.hwid) $("#site-hwid").textContent = data.hwid;

    const badge = $("#files-badge");
    badge.classList.toggle("is-ok", state.installed);
    $("#files-text").textContent = state.installed ? "Файлы установлены" : "Файлы не установлены";

    if (state.settings) {
      $("#play-ram").textContent = formatRam(state.settings.ramMb);
      $("#ram-value").textContent = formatRam(state.settings.ramMb);
      const ram = $("#ram");
      if (document.activeElement !== ram) {
        ram.value = state.settings.ramMb;
      }
      const width = $("#width");
      const height = $("#height");
      if (document.activeElement !== width) width.value = state.settings.width;
      if (document.activeElement !== height) height.value = state.settings.height;
      $("#game-dir").value = state.settings.gameDir || "";
      const java = $("#java-path");
      if (document.activeElement !== java) java.value = state.settings.javaPath || "";
      const jvm = $("#jvm-args");
      if (document.activeElement !== jvm) jvm.value = state.settings.jvmArgs || "";
      $("#close-on-launch").checked = Boolean(state.settings.closeOnLaunch);
    }

    renderAccounts();
    renderMods();
    setActiveAccountUI();

    if (state.settings) {
      const version = state.settings.version || "26.2";
      $("#mod-search-hint").textContent =
        "Ищем только Fabric-моды под Minecraft " + version + ". Скачивание сразу в папку игры.";
    }
  }

  function showProgress(data) {
    const card = $("#progress-card");
    card.classList.remove("is-hidden");

    $("#progress-phase").textContent = phaseLabels[data.phase] || data.phase || "Подготовка";
    $("#progress-file").textContent = data.file || data.label || "Проверяем файлы";

    const bar = $("#progress-bar");
    const indeterminate = Boolean(data.indeterminate) || !data.total;
    bar.classList.toggle("is-indeterminate", indeterminate);

    if (!indeterminate) {
      const percent = Math.max(0, Math.min(100, (data.done / data.total) * 100));
      bar.style.width = percent.toFixed(1) + "%";
      $("#progress-percent").textContent = Math.floor(percent) + "%";
    } else {
      bar.style.width = "";
      $("#progress-percent").textContent = "…";
    }

    let info = formatBytes(data.done) + " / " + formatBytes(data.total);
    if (data.filesTotal) {
      info += " · " + data.filesDone + " из " + data.filesTotal + " файлов";
    }
    $("#progress-info").textContent = info;
  }

  function hideProgress() {
    $("#progress-card").classList.add("is-hidden");
  }

  function openSite(path) {
    const base = (state.siteUrl || "https://stellar-client.vercel.app").replace(/\/+$/, "");
    send({ cmd: "openUrl", url: base + path });
  }

  function bindMods() {
    $("#btn-add-mod").addEventListener("click", () => send({ cmd: "addMods" }));
    $("#btn-open-mods").addEventListener("click", () => send({ cmd: "openMods" }));

    const runSearch = () => {
      const query = $("#mod-search").value.trim();
      if (!query || state.searching) {
        if (!query) $("#mod-search").focus();
        return;
      }
      state.searching = true;
      state.searchError = "";
      state.searchResults = [];
      renderSearchResults();
      send({ cmd: "searchMods", query });
    };

    $("#btn-search-mods").addEventListener("click", runSearch);
    $("#mod-search").addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        runSearch();
      }
    });

    $("#search-results").addEventListener("click", (event) => {
      const button = event.target.closest("[data-download]");
      if (!button) return;
      const id = button.dataset.download;
      const mod = state.searchResults.find((item) => item.id === id);
      if (!mod || state.installing[id]) return;
      state.installing[id] = true;
      renderSearchResults();
      send({ cmd: "installMod", id, title: mod.title });
    });

    $("#mods-list").addEventListener("change", (event) => {
      const input = event.target.closest('input[data-action="toggle"]');
      if (!input) return;
      const row = input.closest(".mod-row");
      if (!row) return;
      send({ cmd: "toggleMod", file: row.dataset.file, enabled: input.checked });
    });

    $("#mods-list").addEventListener("click", (event) => {
      const button = event.target.closest('[data-action="remove"]');
      if (!button) return;
      const row = button.closest(".mod-row");
      if (!row) return;
      send({ cmd: "removeMod", file: row.dataset.file });
    });

    const zone = $("#dropzone");
    const setOver = (value) => zone.classList.toggle("is-over", value);
    ["dragenter", "dragover"].forEach((name) => {
      zone.addEventListener(name, (event) => {
        event.preventDefault();
        event.stopPropagation();
        setOver(true);
      });
    });
    ["dragleave", "dragend"].forEach((name) => {
      zone.addEventListener(name, () => setOver(false));
    });
    zone.addEventListener("drop", (event) => {
      event.preventDefault();
      event.stopPropagation();
      setOver(false);

      const files = Array.from(event.dataTransfer && event.dataTransfer.files ? event.dataTransfer.files : []);
      const api = window.chrome && window.chrome.webview;
      if (!files.length) return;
      if (api && typeof api.postMessageWithAdditionalObjects === "function") {
        api.postMessageWithAdditionalObjects({ cmd: "addModFiles" }, files);
      } else {
        toast("error", "Перетаскивание недоступно — нажми «Добавить мод»");
      }
    });

    document.addEventListener("dragover", (event) => event.preventDefault());
    document.addEventListener("drop", (event) => event.preventDefault());
  }

  function bindStaticEvents() {
    $$("[data-page]").forEach((node) => {
      node.addEventListener("click", (event) => {
        event.preventDefault();
        navigate(node.dataset.page);
      });
    });

    $("#btn-min").addEventListener("click", () => send({ cmd: "minimize" }));
    $("#btn-close").addEventListener("click", () => send({ cmd: "close" }));

    const drag = $(".titlebar");
    drag.addEventListener("mousedown", (event) => {
      if (event.button !== 0) return;
      if (event.target.closest("button")) return;
      send({ cmd: "dragStart" });
    });

    $("#btn-play").addEventListener("click", () => send({ cmd: "play" }));
    $("#btn-cancel").addEventListener("click", () => send({ cmd: "cancel" }));

    $("#site-form").addEventListener("submit", (event) => {
      event.preventDefault();
      const username = $("#site-username").value.trim();
      const password = $("#site-password").value;
      if (!username || !password || state.loginActive) {
        if (!username) $("#site-username").focus();
        else if (!password) $("#site-password").focus();
        return;
      }

      const error = $("#site-error");
      error.classList.add("is-hidden");
      error.textContent = "";
      state.loginActive = true;
      setActiveAccountUI();
      send({ cmd: "siteLogin", username, password });
    });

    $("#btn-open-register").addEventListener("click", () => openSite("/register"));
    $("#btn-open-pricing").addEventListener("click", () => openSite("/pricing"));
    $("#btn-open-dashboard").addEventListener("click", () => openSite("/dashboard"));

    $("#account-list").addEventListener("click", (event) => {
      const item = event.target.closest(".account-item");
      if (!item) return;
      const id = item.dataset.id;
      const action = event.target.closest("[data-action]");
      if (!id) return;
      if (action && action.dataset.action === "remove") {
        send({ cmd: "removeAccount", id });
        return;
      }
      if (!state.activeAccount || state.activeAccount.id !== id) {
        send({ cmd: "selectAccount", id });
      }
    });

    $("#ram").addEventListener("input", (event) => {
      $("#ram-value").textContent = formatRam(Number(event.target.value));
    });

    $("#btn-save").addEventListener("click", () => {
      send({
        cmd: "saveSettings",
        settings: {
          ramMb: Number($("#ram").value),
          width: Number($("#width").value),
          height: Number($("#height").value),
          gameDir: $("#game-dir").value,
          javaPath: $("#java-path").value.trim(),
          jvmArgs: $("#jvm-args").value.trim(),
          closeOnLaunch: $("#close-on-launch").checked,
        },
      });
    });

    $("#btn-open-dir").addEventListener("click", () => send({ cmd: "openGameDir" }));
    $("#btn-open-logs").addEventListener("click", () => send({ cmd: "openLogs" }));
    $("#btn-refresh-logs").addEventListener("click", () => send({ cmd: "refreshLogs" }));

    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && document.activeElement) {
        document.activeElement.blur();
      }
    });

    bindMods();
  }

  function handleEvent(message) {
    if (!message || typeof message !== "object") return;
    switch (message.type) {
      case "state":
        applyState(message.data || {});
        break;
      case "progress":
        showProgress(message.data || {});
        break;
      case "toast":
        toast(message.data && message.data.kind, (message.data && message.data.text) || "");
        break;
      case "logs":
        $("#log-output").textContent = (message.data && message.data.text) || "Пока пусто";
        break;
      case "modSearch": {
        const data = message.data || {};
        state.searching = false;
        state.searchError = data.error || "";
        state.searchResults = Array.isArray(data.results) ? data.results : [];
        renderSearchResults();
        break;
      }
      case "modInstalled": {
        const data = message.data || {};
        delete state.installing[data.id];
        if (!data.error) {
          state.installedSearch[data.id] = true;
        }
        renderSearchResults();
        break;
      }
      case "launched":
        hideProgress();
        break;
      case "loginDone": {
        const data = message.data || {};
        state.loginActive = false;
        $("#site-password").value = "";
        const error = $("#site-error");
        error.classList.add("is-hidden");
        error.textContent = "";
        if (data.account) {
          state.activeAccount = data.account;
        }
        setActiveAccountUI();
        break;
      }
      case "loginError": {
        const text = (message.data && message.data.text) || "Вход не удался";
        state.loginActive = false;
        const error = $("#site-error");
        error.textContent = text;
        error.classList.remove("is-hidden");
        setActiveAccountUI();
        toast("error", text);
        break;
      }
      default:
        break;
    }
  }

  function connect() {
    const api = window.chrome && window.chrome.webview;
    if (!api) {
      document.body.insertAdjacentHTML(
        "beforeend",
        '<div class="toast toast-error" style="position:fixed;left:18px;bottom:18px;z-index:99">Нет связи с лаунчером</div>'
      );
      return;
    }
    api.addEventListener("message", (event) => handleEvent(event.data));
    send({ cmd: "ready" });
  }

  document.addEventListener("DOMContentLoaded", () => {
    bindStaticEvents();
    connect();
  });
})();
